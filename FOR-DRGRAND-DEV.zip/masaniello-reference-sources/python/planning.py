"""Trade-count picker options -- ported from app.js's updateComputedPlan. For
a given bankroll/win-rate/payout, lists every N from 1 up to whatever
computeMaxTrades confirms is affordable (trade-1 stake >= $1), each with its
projected growth if the plan lands exactly on target."""

from typing import Optional

from trading_hud.trade_manager.masaniello import (
    build_table,
    compute_max_trades,
    next_stake,
    threshold_amount,
    wins_needed_for_rate,
)

MAX_TRADE_COUNT_OPTIONS = 20

# Hard ceiling for suggest_multiday_plan_options' search, independent of
# whatever max_trades_per_day x days_available works out to -- that product
# is user-controlled and unbounded (a far-out target date x a generous
# per-day rate can reach into the thousands), but the search cost grows
# roughly with the CUBE of trade count (one build_table(n, ...) -- O(n^2) --
# per candidate n from 1..max). Measured empirically: ~0.23s at 200,
# ~4.7s at 500. 200 keeps it imperceptible for a synchronous button click;
# see suggest_multiday_plan_options' docstring.
MAX_MULTIDAY_SEARCH_TRADES = 200

# Grid the "suggest best plan" search steps win rate over -- 1% resolution is
# cheap here (see suggest_best_plan's docstring for the cost) and gives an
# answer indistinguishable from a continuous search for planning purposes.
_SUGGEST_WIN_RATE_MIN = 1.0
_SUGGEST_WIN_RATE_MAX = 99.0
_SUGGEST_WIN_RATE_STEP = 1.0


def compute_trade_count_options(
    bankroll: float,
    win_rate_pct: float,
    avg_payout_pct: float,
    diagonal_mode: str,
    max_stake_percent: Optional[float],
    max_options: int = MAX_TRADE_COUNT_OPTIONS,
    stop_loss: Optional[dict] = None,
) -> dict:
    """Returns {'options': [...], 'cappedAtSearchLimit': bool}. options is
    empty if inputs are invalid or the bankroll can't fund even one trade.

    Each option also carries firstTradeStake and survivesFirstLoss.
    survivesFirstLoss answers "if trade 1 (the biggest single unknown --
    nothing recorded yet to react to) loses, does that alone cross the
    stop_loss threshold?" -- i.e. current_capital after one loss is
    bankroll - firstTradeStake, and session.check_end_conditions() ends the
    session on stop_loss once (c0 - current_capital) >= threshold_amount(c0,
    stop_loss), which for trade 1 specifically reduces to firstTradeStake >=
    threshold_amount(c0, stop_loss). This mirrors that condition exactly
    (see trade_manager/session.py's check_end_conditions) so the two never
    disagree about what "instantly hits stop-loss" means. Deliberately
    ignores stop_loss.get("forceEnd") -- that toggle controls whether the
    session *auto-ends* on the threshold, not whether the threshold itself
    is meaningfully crossed, and this field is about the latter. If
    stop_loss is None, every option reports survivesFirstLoss=True (no
    constraint to violate)."""
    if not (bankroll > 0) or not (win_rate_pct > 0) or not (avg_payout_pct > 0):
        return {"options": [], "cappedAtSearchLimit": False}

    result = compute_max_trades(bankroll, win_rate_pct, avg_payout_pct, diagonal_mode, max_stake_percent, 1, max_options)
    if result["n"] < 1:
        return {"options": [], "cappedAtSearchLimit": False}

    sl_amount = threshold_amount(bankroll, stop_loss) if stop_loss is not None else None
    q_avg = avg_payout_pct / 100

    options = []
    for n in range(1, result["n"] + 1):
        k = wins_needed_for_rate(n, win_rate_pct)
        table = build_table(n, q_avg)
        projected_final = bankroll * table[n][k]
        profit = projected_final - bankroll
        first_trade_stake = next_stake(bankroll, n, k, q_avg, table, diagonal_mode, max_stake_percent)
        survives_first_loss = sl_amount is None or first_trade_stake < sl_amount
        options.append(
            {
                "n": n,
                "k": k,
                "projectedFinal": projected_final,
                "profit": profit,
                "profitPct": (profit / bankroll) * 100,
                "firstTradeStake": first_trade_stake,
                "survivesFirstLoss": survives_first_loss,
            }
        )

    return {"options": options, "cappedAtSearchLimit": result["cappedAtSearchLimit"]}


def suggest_best_plan(
    bankroll: float,
    avg_payout_pct: float,
    diagonal_mode: str,
    max_stake_percent: Optional[float],
    stop_loss: dict,
    max_trade_count: int = MAX_TRADE_COUNT_OPTIONS,
) -> Optional[dict]:
    """Searches assumed win rate (1%-99%, 1% steps) x every trade count up to
    max_trade_count each one affords, for the single (win_rate_pct, n)
    combination that maximizes projected profit while still surviving a
    single first-trade loss without crossing stop_loss (see
    compute_trade_count_options's survivesFirstLoss). Returns the winning
    option dict (same shape as compute_trade_count_options's entries, plus
    'winRatePct'), or None if nothing in the search space survives --
    meaning no win-rate/trade-count combination fits this stop-loss at this
    bankroll at all (stop-loss is very tight relative to bankroll, or payout
    is too low to fund a safe plan).

    This is NOT a degenerate "always pick the highest win rate" search: for
    a fixed trade count, a *higher* assumed win rate needs a *larger* first
    stake (more wins required relative to trades means more aggressive
    staking), so raising the win-rate assumption trades safety for profit
    rather than improving both -- the stop-loss constraint genuinely bounds
    how high a win rate this can suggest, it doesn't just pick the grid's
    ceiling. (Verified empirically before writing this: at a fixed n, stake1
    increases monotonically with win_rate in every case checked.)

    It genuinely IS degenerate in trade count, though, if left unbounded:
    for a *fixed* win rate, *more* trades spreads the same risk thinner
    (smaller, safer first stake) while also raising the profit ceiling, so
    "maximize profit subject to safety" alone pushes n toward whatever the
    ceiling is almost regardless of bankroll/stop-loss -- confirmed
    empirically (a range of very different bankroll/payout/stop-loss inputs
    all landed within 1-2 of MAX_TRADE_COUNT_OPTIONS). Reported by the user
    as impractical ("20 trades is a lot to take in a single session") --
    max_trade_count exists specifically so the caller controls that ceiling
    instead of it silently defaulting to the app's overall 20-trade search
    limit. Don't "fix" the degeneracy some other way (e.g. penalizing
    profit-per-trade) without the user asking for that instead; capping the
    search space directly is what was asked for.

    Cost: ~99 win-rate steps x up to max_trade_count trade counts each, each
    a compute_max_trades search (bounded by max_trade_count) plus an O(n^2)
    table build -- a few hundred thousand basic operations worst case at the
    default ceiling, well under a second in pure Python. Fine to call
    synchronously from a button click; no threading needed."""
    if not (bankroll > 0) or not (avg_payout_pct > 0):
        return None
    if not (max_trade_count >= 1):
        return None
    sl_amount = threshold_amount(bankroll, stop_loss)
    if not (sl_amount > 0):
        return None  # a zero/negative threshold can never be survived

    best: Optional[dict] = None
    steps = int(round((_SUGGEST_WIN_RATE_MAX - _SUGGEST_WIN_RATE_MIN) / _SUGGEST_WIN_RATE_STEP))
    for i in range(steps + 1):
        win_rate_pct = _SUGGEST_WIN_RATE_MIN + i * _SUGGEST_WIN_RATE_STEP
        result = compute_trade_count_options(
            bankroll,
            win_rate_pct,
            avg_payout_pct,
            diagonal_mode,
            max_stake_percent,
            max_options=max_trade_count,
            stop_loss=stop_loss,
        )
        for opt in result["options"]:
            if not opt["survivesFirstLoss"]:
                continue
            if best is None or opt["profitPct"] > best["profitPct"]:
                best = {**opt, "winRatePct": win_rate_pct}

    return best


def suggest_multiday_plan_options(
    bankroll: float,
    target_gain_pct: float,
    avg_payout_pct: float,
    diagonal_mode: str,
    max_stake_percent: Optional[float],
    stop_loss: Optional[dict],
    days_available: int,
    max_total_trades: int = MAX_TRADE_COUNT_OPTIONS,
) -> dict:
    """For a target gain by some future date, spread over days_available
    days: for each candidate total trade count n (1..max_total_trades,
    internally clamped to MAX_MULTIDAY_SEARCH_TRADES regardless of what's
    passed in -- see that constant), finds the MINIMUM k such that landing
    on exactly k wins out of n reaches target_gain_pct -- i.e. the
    least-demanding (safest) win rate that still gets there for that many
    total trades. This is a genuinely different search direction from
    suggest_best_plan(): that one fixes nothing and maximizes profit
    subject to a safety constraint; this one fixes the profit target and,
    for each trade count, finds the minimum win rate that reaches it --
    there's no "maximize" step here, every n that can reach the target gets
    exactly one (its safest) option, and the caller presents the whole list
    rather than picking a single winner, since which trade-count/pace
    tradeoff is acceptable is the user's call, not something profit/safety
    alone can decide (unlike suggest_best_plan, where trade count has no
    such external constraint and safety numbers alone are enough to pick
    one).

    max_total_trades is expressed as a TOTAL here -- the caller (the
    Multi-Day setup screen) exposes a "max trades per day" input instead
    and multiplies by days_available before calling this, so from this
    function's point of view there's no real difference between a
    long-timeframe/low-rate plan and a short-timeframe/high-rate one that
    happen to produce the same total. tradesPerDay in each returned option
    (n / days_available) is purely informational either way, never a
    constraint the search itself enforces.

    Returns {'options': [...], 'cappedAtSearchLimit': bool} -- options has
    one dict per achievable n (skips any n where even winning every single
    trade doesn't reach target_gain_pct -- not enough trades to possibly
    get there): {n, k, winRatePct, tradesPerDay, projectedFinal, profit,
    profitPct, firstTradeStake, survivesFirstLoss}. cappedAtSearchLimit is
    True when max_total_trades (e.g. max_trades_per_day x days_available)
    exceeded MAX_MULTIDAY_SEARCH_TRADES and got clamped -- the caller
    should tell the user the search stopped short of what their own
    inputs implied, same spirit as compute_trade_count_options'
    cappedAtSearchLimit.

    Relies on build_table(n, q)[n][k] being monotonically non-decreasing in
    k for fixed n (verified empirically before writing this, across a
    range of payout ratios and trade counts) -- that's what makes "smallest
    k that clears the target" well-defined via a plain linear scan instead
    of needing something more careful."""
    if not (bankroll > 0) or not (avg_payout_pct > 0) or not (target_gain_pct > 0):
        return {"options": [], "cappedAtSearchLimit": False}
    if not (days_available >= 1) or not (max_total_trades >= 1):
        return {"options": [], "cappedAtSearchLimit": False}

    capped = max_total_trades > MAX_MULTIDAY_SEARCH_TRADES
    max_total_trades = min(max_total_trades, MAX_MULTIDAY_SEARCH_TRADES)

    target_mult = 1 + target_gain_pct / 100
    q_avg = avg_payout_pct / 100
    sl_amount = threshold_amount(bankroll, stop_loss) if stop_loss is not None else None

    options = []
    for n in range(1, max_total_trades + 1):
        table = build_table(n, q_avg)
        if table[n][n] < target_mult:
            continue  # not reachable even winning every single trade
        k = next(kk for kk in range(1, n + 1) if table[n][kk] >= target_mult)
        win_rate_pct = k / n * 100
        projected_final = bankroll * table[n][k]
        profit = projected_final - bankroll
        first_trade_stake = next_stake(bankroll, n, k, q_avg, table, diagonal_mode, max_stake_percent)
        survives_first_loss = sl_amount is None or first_trade_stake < sl_amount
        options.append(
            {
                "n": n,
                "k": k,
                "winRatePct": win_rate_pct,
                "tradesPerDay": n / days_available,
                "projectedFinal": projected_final,
                "profit": profit,
                "profitPct": (profit / bankroll) * 100,
                "firstTradeStake": first_trade_stake,
                "survivesFirstLoss": survives_first_loss,
            }
        )

    return {"options": options, "cappedAtSearchLimit": capped}
