"""Direct port of Examples/trademanager/masaniello.js. Function shapes and
edge-case handling (diagonal pure/capped, threshold amount/floor/ceiling,
computeMaxTrades' first-shortfall-is-the-ceiling rule) are kept 1:1 with the
reference implementation -- see Examples/trademanager/PROJECT_SUMMARY.md and
Downloads/masaniello-risk-tool-prompt.md section 3.3 for the algorithm spec.
Do not change the math here without re-running trade_manager/test_masaniello.py."""

from typing import Optional


def build_table(n: int, q_avg: float) -> list[list[float]]:
    if not isinstance(n, int) or n < 0:
        raise ValueError("n must be a non-negative integer")
    size = n + 1
    t = [[0.0] * size for _ in range(size)]

    for nn in range(size):
        t[nn][0] = 1.0  # target already met -- stop staking, session done

    for m in range(size):
        t[m][m] = (1 + q_avg) ** m  # must-win-every-remaining-trade case

    for nn in range(1, size):
        for k in range(1, nn):  # kMax = nn-1 always, since nn <= n throughout
            a = t[nn - 1][k - 1]  # multiplier if this trade wins
            b = t[nn - 1][k]  # multiplier if this trade loses
            t[nn][k] = (a * b * (1 + q_avg)) / (a * q_avg + b)

    return t


def stake_fraction(
    n: int,
    k: int,
    q_next: float,
    t: list[list[float]],
    diagonal_mode: str,
    max_stake_percent: Optional[float],
) -> float:
    if k <= 0:
        return 0.0  # already hit target win count -- stop risking capital
    if n <= k:
        if diagonal_mode == "capped":
            cap = max_stake_percent if isinstance(max_stake_percent, (int, float)) else 100
            return min(1.0, max(0.0, cap / 100))
        return 1.0  # pure mode: must-win-all-remaining, stake it all
    a = t[n - 1][k - 1]
    b = t[n - 1][k]
    denom = a * q_next + b
    if denom <= 0:
        return 0.0
    return (b - a) / denom


def next_stake(
    current_capital: float,
    trades_remaining: int,
    wins_still_needed: int,
    q_next: float,
    t: list[list[float]],
    diagonal_mode: str,
    max_stake_percent: Optional[float],
) -> float:
    frac = stake_fraction(trades_remaining, wins_still_needed, q_next, t, diagonal_mode, max_stake_percent)
    return current_capital * frac


def threshold_amount(bankroll: float, tp_sl: dict) -> float:
    """tp_sl = {'type': 'percent'|'dollar', 'value': ..., 'dollarMode': ...}.
    dollarMode disambiguates 'amount' (cumulative $ gain/loss from bankroll,
    the default) from 'floor'/'ceiling' (target balance itself)."""
    if tp_sl["type"] == "percent":
        return bankroll * (tp_sl["value"] / 100)
    if tp_sl.get("dollarMode") == "floor":
        return max(0.0, bankroll - tp_sl["value"])
    if tp_sl.get("dollarMode") == "ceiling":
        return max(0.0, tp_sl["value"] - bankroll)
    return tp_sl["value"]  # default 'amount' mode


def wins_needed_for_rate(n: int, win_rate_pct: float) -> int:
    return min(n, max(1, round((win_rate_pct / 100) * n)))


def compute_max_trades(
    bankroll: float,
    win_rate_pct: float,
    avg_payout_pct: float,
    diagonal_mode: str,
    max_stake_percent: Optional[float],
    min_stake: float = 1,
    max_search_n: int = 300,
) -> dict:
    if not (bankroll >= min_stake) or not (win_rate_pct > 0) or not (avg_payout_pct > 0):
        return {"n": 0, "k": 0, "achievedWinRatePct": 0.0, "cappedAtSearchLimit": False}

    q = avg_payout_pct / 100
    best_n = 0
    best_k = 0

    for n in range(1, max_search_n + 1):
        k = wins_needed_for_rate(n, win_rate_pct)
        table = build_table(n, q)
        stake1 = bankroll * stake_fraction(n, k, q, table, diagonal_mode, max_stake_percent)
        if stake1 >= min_stake - 1e-9:
            best_n = n
            best_k = k
        else:
            break

    return {
        "n": best_n,
        "k": best_k,
        "achievedWinRatePct": (best_k / best_n * 100) if best_n > 0 else 0.0,
        "cappedAtSearchLimit": best_n == max_search_n,
    }
