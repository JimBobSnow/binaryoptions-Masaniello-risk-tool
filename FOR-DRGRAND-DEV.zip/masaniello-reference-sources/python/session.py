"""Session lifecycle -- ported from Examples/trademanager/app.js. Same data
shape (a plain dict matching the JS session object), same end-condition
priority order, same round-to-cents behavior. Do not invent new business
rules here; if the setup flow needs to change, read this alongside app.js's
updateComputedPlan/applySelectedTradeCount (see PROJECT_SUMMARY.md).

One deliberate adaptation for this non-interactive context: app.js rejects
(with a form error) a stake-used entry that exceeds current capital, since a
human is typing it into a form. Here stake_used comes from OCR of the
broker's amount field after the trade has already happened, so there's
nothing to "reject" -- it's clamped to current capital instead. The staking
math, end-condition logic, and data shape are otherwise unchanged."""

import uuid as _uuid
from datetime import datetime
from typing import Optional

from trading_hud.trade_manager.masaniello import build_table, next_stake, threshold_amount

END_REASON_LABELS = {
    "take_profit": "Take Profit Hit",
    "stop_loss": "Stop Loss Hit",
    "target_hit": "Target Hit",
    "target_unreachable": "Target Unreachable",
    "trades_exhausted": "Trades Exhausted",
    "manual": "Ended Manually",
}


def _round2(n: float) -> float:
    return round(n + 1e-9, 2)


def _clamp(n: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, n))


def create_session(
    bankroll: float,
    n: int,
    k: int,
    avg_payout_pct: float,
    take_profit: dict,
    stop_loss: dict,
    diagonal_mode: str,
    max_stake_percent: Optional[float],
) -> dict:
    return {
        "id": str(_uuid.uuid4()),
        "startedAt": datetime.now().isoformat(),
        "status": "active",
        "inputs": {
            "bankroll": bankroll,
            "N": n,
            "K": k,
            "avgPayoutPct": avg_payout_pct,
            "takeProfit": dict(take_profit),
            "stopLoss": dict(stop_loss),
            "diagonalMode": diagonal_mode,
            "maxStakePercent": max_stake_percent,
        },
        "currentCapital": bankroll,
        "tradesRemaining": n,
        "winsNeeded": k,
        "trades": [],
        "endReason": None,
        "endedAt": None,
    }


def build_session_table(session: dict) -> list[list[float]]:
    return build_table(session["inputs"]["N"], session["inputs"]["avgPayoutPct"] / 100)


def suggested_stake_for(session: dict, table: list[list[float]], q_next_pct: float) -> float:
    q_next = q_next_pct / 100
    inputs = session["inputs"]
    return next_stake(
        session["currentCapital"],
        session["tradesRemaining"],
        session["winsNeeded"],
        q_next,
        table,
        inputs["diagonalMode"],
        inputs["maxStakePercent"],
    )


def check_end_conditions(session: dict) -> Optional[str]:
    """Priority order: mathematical impossibility, then the win target, then
    the profit/loss dollar overlay, then running out of trades."""
    inputs = session["inputs"]
    c0 = inputs["bankroll"]
    current_capital = session["currentCapital"]

    if session["tradesRemaining"] < session["winsNeeded"]:
        return "target_unreachable"
    if session["winsNeeded"] == 0:
        return "target_hit"

    tp_amt = threshold_amount(c0, inputs["takeProfit"])
    if inputs["takeProfit"].get("forceEnd", True) is not False and current_capital - c0 >= tp_amt:
        return "take_profit"

    sl_amt = threshold_amount(c0, inputs["stopLoss"])
    if inputs["stopLoss"].get("forceEnd", True) is not False and c0 - current_capital >= sl_amt:
        return "stop_loss"

    if session["tradesRemaining"] == 0:
        return "trades_exhausted"
    return None


def end_session(session: dict, reason: str) -> dict:
    """Mutates session in place to 'ended' and returns an archive record
    matching the JS history entry shape."""
    session["status"] = "ended"
    session["endReason"] = reason
    session["endedAt"] = datetime.now().isoformat()

    net_pl = _round2(session["currentCapital"] - session["inputs"]["bankroll"])
    return {
        "id": session["id"],
        "startedAt": session["startedAt"],
        "endedAt": session["endedAt"],
        "inputs": dict(session["inputs"]),
        "trades": list(session["trades"]),
        "endReason": reason,
        "finalCapital": _round2(session["currentCapital"]),
        "netPL": net_pl,
        "netPLPercent": _round2((net_pl / session["inputs"]["bankroll"]) * 100),
    }


def record_trade(session: dict, result: str, q_next_pct: float, stake_used: Optional[float] = None) -> Optional[dict]:
    """Records a trade result, advances session state, and returns an archive
    record (see end_session) if this trade ended the session, else None."""
    table = build_session_table(session)
    suggested = _round2(_clamp(suggested_stake_for(session, table, q_next_pct), 0, session["currentCapital"]))
    if stake_used is None or stake_used < 0:
        stake_used = suggested
    stake_used = _round2(min(stake_used, session["currentCapital"]))

    capital_after = (
        _round2(session["currentCapital"] + stake_used * (q_next_pct / 100))
        if result == "win"
        else _round2(session["currentCapital"] - stake_used)
    )

    session["trades"].append(
        {
            "index": len(session["trades"]) + 1,
            "payoutPctUsed": q_next_pct,
            "stakeSuggested": suggested,
            "stakeUsed": stake_used,
            "result": result,
            "capitalAfter": capital_after,
        }
    )

    session["currentCapital"] = capital_after
    session["tradesRemaining"] -= 1
    if result == "win":
        session["winsNeeded"] -= 1

    reason = check_end_conditions(session)
    if reason:
        return end_session(session, reason)
    return None


def edit_trade_result(session: dict, idx: int, new_result: str) -> Optional[dict]:
    """Inline correction, only valid while the session is still active.
    Recomputes every downstream capitalAfter, then re-checks end conditions
    (fixing a misclick can retroactively end the session)."""
    if session["status"] != "active":
        return None
    trades = session["trades"]
    if idx < 1 or idx > len(trades):
        return None
    trade = trades[idx - 1]
    if trade["result"] == new_result:
        return None
    trade["result"] = new_result

    for i in range(idx - 1, len(trades)):
        t = trades[i]
        before = session["inputs"]["bankroll"] if i == 0 else trades[i - 1]["capitalAfter"]
        t["capitalAfter"] = (
            _round2(before + t["stakeUsed"] * (t["payoutPctUsed"] / 100))
            if t["result"] == "win"
            else _round2(before - t["stakeUsed"])
        )

    wins = sum(1 for t in trades if t["result"] == "win")
    session["currentCapital"] = trades[-1]["capitalAfter"] if trades else session["inputs"]["bankroll"]
    session["tradesRemaining"] = session["inputs"]["N"] - len(trades)
    session["winsNeeded"] = session["inputs"]["K"] - wins

    reason = check_end_conditions(session)
    if reason:
        return end_session(session, reason)
    return None
