"""Ported 1:1 from Examples/trademanager/tests.html -- same cases, same
tolerances. Run directly: .venv/bin/python3 -m trading_hud.trade_manager.test_masaniello
Whenever masaniello.py changes, re-run this before trusting the change."""

import sys

from trading_hud.trade_manager.masaniello import (
    build_table,
    compute_max_trades,
    next_stake,
    stake_fraction,
    threshold_amount,
)

_results: list[tuple[str, bool, float, float]] = []


def approx(a: float, b: float, eps: float = 0.005) -> bool:
    return abs(a - b) <= eps


def check(name: str, actual: float, expected: float, eps: float = 0.005) -> None:
    ok = approx(actual, expected, eps)
    _results.append((name, ok, actual, expected))


def worked_example() -> None:
    n, k, q_avg, c0 = 3, 1, 1.0, 100
    t = build_table(n, q_avg)

    capital, trades_remaining, wins_needed = c0, n, k

    stake1 = next_stake(capital, trades_remaining, wins_needed, q_avg, t, "pure", None)
    check("Trade 1 stake ~ $14.29", stake1, 14.29, 0.01)

    capital -= stake1
    trades_remaining -= 1
    check("Capital after loss 1 ~ $85.71", capital, 85.71, 0.01)

    stake2 = next_stake(capital, trades_remaining, wins_needed, q_avg, t, "pure", None)
    check("Trade 2 stake ~ $28.57", stake2, 28.57, 0.01)

    capital -= stake2
    trades_remaining -= 1
    check("Capital after loss 2 ~ $57.14", capital, 57.14, 0.01)

    stake3 = next_stake(capital, trades_remaining, wins_needed, q_avg, t, "pure", None)
    check("Trade 3 stake = 100% of remaining ($57.14)", stake3, 57.14, 0.01)

    s1 = next_stake(c0, n, k, q_avg, t, "pure", None)
    final_if_win_trade1 = c0 - s1 + s1 * (1 + q_avg)
    check("Win-on-trade-1 final capital ~ $114.29", final_if_win_trade1, 114.29, 0.02)

    final_if_win_trade3 = capital - stake3 + stake3 * (1 + q_avg)
    check("Win-on-trade-3 (last) final capital ~ $114.28", final_if_win_trade3, 114.28, 0.02)


def q_next_differs_from_q_avg() -> None:
    n, k, q_avg, c0 = 3, 1, 0.80, 100
    t = build_table(n, q_avg)
    q_next = 0.92

    stake_with_q_next = next_stake(c0, n, k, q_next, t, "pure", None)
    stake_with_q_avg = next_stake(c0, n, k, q_avg, t, "pure", None)
    check("Stake with q_next=0.92 differs from stake with q_avg=0.80", 0 if stake_with_q_next == stake_with_q_avg else 1, 1, 0)

    return_if_win = stake_with_q_next * q_next
    wrong_return_if_win = stake_with_q_next * q_avg
    check("Return on win uses q_next, not q_avg (values differ)", 0 if return_if_win == wrong_return_if_win else 1, 1, 0)

    a_q = t[n - 1][k - 1]
    b_q = t[n - 1][k]
    expected_fraction = (b_q - a_q) / (a_q * q_next + b_q)
    check(
        "stakeFraction(N,K,q_next) matches manual formula using table built on q_avg",
        stake_fraction(n, k, q_next, t, "pure", None),
        expected_fraction,
        1e-9,
    )


def target_met() -> None:
    t = build_table(5, 0.8)
    check("stakeFraction returns 0 once k=0 (target met)", stake_fraction(3, 0, 0.8, t, "pure", None), 0, 0)


def diagonal_modes() -> None:
    t = build_table(4, 0.8)
    check("Pure mode diagonal (n=k) stakes 100%", stake_fraction(2, 2, 0.8, t, "pure", None), 1, 0)
    check("Capped mode diagonal (n=k) respects 50% cap", stake_fraction(2, 2, 0.8, t, "capped", 50), 0.5, 0)
    check("Capped mode diagonal respects 100% cap == pure", stake_fraction(2, 2, 0.8, t, "capped", 100), 1, 0)


def additional_combos() -> None:
    n, k, q_avg = 5, 3, 0.80
    t = build_table(n, q_avg)
    check("t[n][0] = 1 for all n", t[5][0] + t[3][0] + t[0][0], 3, 0)
    check("t[m][m] = (1+q)^m diagonal (m=2)", t[2][2], 1.8**2, 1e-9)
    check("t[m][m] = (1+q)^m diagonal (m=5)", t[5][5], 1.8**5, 1e-9)

    c0 = 250
    stake = next_stake(c0, n, k, q_avg, t, "pure", None)
    capital_after_win = c0 - stake + stake * (1 + q_avg)
    projected_from_start = c0 * t[n][k]
    projected_after_win = capital_after_win * t[n - 1][k - 1]
    check(
        "Projected final capital is invariant after a win (N=5,K=3,q=0.8)",
        projected_after_win,
        projected_from_start,
        0.01,
    )

    capital_after_loss = c0 - stake
    projected_after_loss = capital_after_loss * t[n - 1][k]
    check(
        "Projected final capital is invariant after a loss (N=5,K=3,q=0.8)",
        projected_after_loss,
        projected_from_start,
        0.01,
    )


def threshold_amount_modes() -> None:
    c0 = 100

    check("Percent TP: 20% of $100 bankroll = $20", threshold_amount(c0, {"type": "percent", "value": 20}), 20, 0)
    check("Percent SL: 30% of $100 bankroll = $30", threshold_amount(c0, {"type": "percent", "value": 30}), 30, 0)

    check("Dollar SL, no dollarMode (legacy): threshold = raw value", threshold_amount(c0, {"type": "dollar", "value": 1}), 1, 0)
    check(
        "Dollar SL, amount mode: threshold = raw value",
        threshold_amount(c0, {"type": "dollar", "value": 1, "dollarMode": "amount"}),
        1,
        0,
    )
    check(
        "Dollar TP, amount mode: threshold = raw value",
        threshold_amount(c0, {"type": "dollar", "value": 20, "dollarMode": "amount"}),
        20,
        0,
    )

    sl_floor_threshold = threshold_amount(c0, {"type": "dollar", "value": 1, "dollarMode": "floor"})
    check("Dollar SL, floor mode: $1 floor on $100 bankroll allows $99 of loss", sl_floor_threshold, 99, 0)
    loss_so_far_at_55_remaining = c0 - 55
    check(
        "At $55 remaining, floor-mode SL of $1 has NOT triggered yet (45 < 99)",
        1 if loss_so_far_at_55_remaining < sl_floor_threshold else 0,
        1,
        0,
    )

    sl_amount_threshold = threshold_amount(c0, {"type": "dollar", "value": 1, "dollarMode": "amount"})
    check(
        "At $55 remaining, amount-mode SL of $1 HAS triggered (45 >= 1)",
        1 if loss_so_far_at_55_remaining >= sl_amount_threshold else 0,
        1,
        0,
    )

    check(
        "Dollar TP, ceiling mode: $150 target balance on $100 bankroll needs $50 profit",
        threshold_amount(c0, {"type": "dollar", "value": 150, "dollarMode": "ceiling"}),
        50,
        0,
    )

    check(
        "Floor mode clamps to 0 when floor value exceeds bankroll",
        threshold_amount(c0, {"type": "dollar", "value": 200, "dollarMode": "floor"}),
        0,
        0,
    )
    check(
        "Ceiling mode clamps to 0 when ceiling value is below bankroll",
        threshold_amount(c0, {"type": "dollar", "value": 50, "dollarMode": "ceiling"}),
        0,
        0,
    )


def max_trades_calc() -> None:
    r6 = compute_max_trades(100, 20, 100, "pure", None)
    check("computeMaxTrades($100, 20% win rate, 100% payout): max trades = 6", r6["n"], 6, 0)
    check("computeMaxTrades(...): wins needed at n=6 stays 1", r6["k"], 1, 0)

    r_too_small = compute_max_trades(0.5, 60, 80, "pure", None)
    check("computeMaxTrades(bankroll < $1 minimum) -> 0 trades", r_too_small["n"], 0, 0)

    r100 = compute_max_trades(100, 100, 80, "pure", None, 1, 10)
    check("computeMaxTrades(100% win rate) hits the search cap (capped flag set)", 1 if r100["cappedAtSearchLimit"] else 0, 1, 0)
    check("computeMaxTrades(100% win rate) reports n = search cap", r100["n"], 10, 0)

    r_invalid = compute_max_trades(100, 0, 80, "pure", None)
    check("computeMaxTrades(0% win rate) -> 0 trades, not a crash", r_invalid["n"], 0, 0)


def main() -> int:
    worked_example()
    q_next_differs_from_q_avg()
    target_met()
    diagonal_modes()
    additional_combos()
    threshold_amount_modes()
    max_trades_calc()

    pass_count = 0
    for name, ok, actual, expected in _results:
        status = "PASS" if ok else "FAIL"
        if ok:
            pass_count += 1
        else:
            print(f"{status} {name} -- got {actual!r}, expected {expected!r}")

    total = len(_results)
    print(f"{pass_count} / {total} passed")
    return 0 if pass_count == total else 1


if __name__ == "__main__":
    sys.exit(main())
