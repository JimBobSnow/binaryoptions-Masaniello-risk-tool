"""Pure-logic tests for planning.py's stop-loss-awareness and auto-suggest
search. Run directly: .venv/bin/python3 -m trading_hud.trade_manager.test_planning
No Qt/display dependency -- same pattern as ocr/test_timer_reader.py."""

from trading_hud.trade_manager.masaniello import build_table, threshold_amount
from trading_hud.trade_manager.planning import (
    MAX_MULTIDAY_SEARCH_TRADES,
    compute_trade_count_options,
    suggest_best_plan,
    suggest_multiday_plan_options,
)

_passed = 0
_failed = 0


def check(label: str, condition: bool) -> None:
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"FAIL: {label}")


BANKROLL = 1000.0
AVG_PAYOUT = 85.0
STOP_LOSS = {"type": "percent", "value": 20, "dollarMode": "amount"}
SL_AMOUNT = threshold_amount(BANKROLL, STOP_LOSS)

# -- compute_trade_count_options: survivesFirstLoss matches the raw
# stake1 >= threshold_amount condition check_end_conditions() uses --
result = compute_trade_count_options(BANKROLL, 70, AVG_PAYOUT, "pure", None, stop_loss=STOP_LOSS)
check("stop-loss-aware search returns options", len(result["options"]) > 0)
for opt in result["options"]:
    expected_safe = opt["firstTradeStake"] < SL_AMOUNT
    check(f"n={opt['n']} survivesFirstLoss matches raw threshold check", opt["survivesFirstLoss"] == expected_safe)

# -- stop_loss=None means vacuously safe (no constraint to violate) --
result_none = compute_trade_count_options(BANKROLL, 70, AVG_PAYOUT, "pure", None, stop_loss=None)
check("stop_loss=None -> every option reports survivesFirstLoss=True", all(o["survivesFirstLoss"] for o in result_none["options"]))

# -- a very tight stop-loss should still return options (n=1..N exist), just
# with none of them safe --
tiny_sl = {"type": "dollar", "value": 1, "dollarMode": "amount"}
result_tiny = compute_trade_count_options(BANKROLL, 70, AVG_PAYOUT, "pure", None, stop_loss=tiny_sl)
check("even an unsurvivable stop-loss still returns unfiltered options", len(result_tiny["options"]) > 0)
check("no option survives a $1 stop-loss on a $1000 bankroll", not any(o["survivesFirstLoss"] for o in result_tiny["options"]))

# -- suggest_best_plan: the result must itself be safe, and genuinely the
# best safe option -- cross-checked against an independent brute-force scan
# of the same search space --
best = suggest_best_plan(BANKROLL, AVG_PAYOUT, "pure", None, STOP_LOSS)
check("suggest_best_plan finds a plan for a reasonable stop-loss", best is not None)
if best is not None:
    check("suggested plan actually survives a first-trade loss", best["survivesFirstLoss"] is True)
    check("suggested plan's stake1 is really under the stop-loss threshold", best["firstTradeStake"] < SL_AMOUNT)

    found_better = False
    for wr in range(1, 100):
        r = compute_trade_count_options(BANKROLL, wr, AVG_PAYOUT, "pure", None, stop_loss=STOP_LOSS)
        for o in r["options"]:
            if o["survivesFirstLoss"] and o["profitPct"] > best["profitPct"] + 1e-9:
                found_better = True
    check("no safe option in the search space beats the suggestion", not found_better)

# -- suggest_best_plan returns None when nothing can survive --
best_impossible = suggest_best_plan(BANKROLL, AVG_PAYOUT, "pure", None, tiny_sl)
check("suggest_best_plan returns None when no plan can survive", best_impossible is None)

# -- suggest_best_plan returns None on invalid inputs rather than raising --
check("suggest_best_plan(bankroll=0, ...) -> None", suggest_best_plan(0, AVG_PAYOUT, "pure", None, STOP_LOSS) is None)
check("suggest_best_plan(avg_payout=0, ...) -> None", suggest_best_plan(BANKROLL, 0, "pure", None, STOP_LOSS) is None)
zero_sl = {"type": "dollar", "value": 0, "dollarMode": "amount"}
check("suggest_best_plan(stop_loss=$0, ...) -> None", suggest_best_plan(BANKROLL, AVG_PAYOUT, "pure", None, zero_sl) is None)

# -- suggest_multiday_plan_options: every returned (n, k) must be the true
# minimum k that reaches the target multiplier for that n -- k-1 (if it
# exists) must NOT reach it --
TARGET_GAIN = 50.0
DAYS = 15
multiday_result = suggest_multiday_plan_options(BANKROLL, TARGET_GAIN, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS, max_total_trades=20)
multiday_options = multiday_result["options"]
check("multiday search returns options for a reasonable target", len(multiday_options) > 0)
check("multiday search under the cap reports cappedAtSearchLimit=False", multiday_result["cappedAtSearchLimit"] is False)
target_mult = 1 + TARGET_GAIN / 100
for opt in multiday_options:
    n, k = opt["n"], opt["k"]
    table = build_table(n, AVG_PAYOUT / 100)
    check(f"n={n} k={k} actually reaches the target multiplier", table[n][k] >= target_mult)
    if k > 0:
        check(f"n={n} k={k} is genuinely minimal (k-1 falls short)", table[n][k - 1] < target_mult)
    check(f"n={n} tradesPerDay matches n/days", abs(opt["tradesPerDay"] - n / DAYS) < 1e-9)
    expected_safe = opt["firstTradeStake"] < SL_AMOUNT
    check(f"n={n} survivesFirstLoss matches raw threshold check", opt["survivesFirstLoss"] == expected_safe)

# -- an unreachable target (more than winning every single trade of the max
# allowed could ever produce) returns no options, not a crash --
huge_gain_result = suggest_multiday_plan_options(BANKROLL, 10_000_000, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS, max_total_trades=5)
check("an unreachable target returns an empty options list, not a crash", huge_gain_result["options"] == [])

# -- invalid inputs return an empty result rather than raising --
check("suggest_multiday_plan_options(bankroll=0, ...) -> no options", suggest_multiday_plan_options(0, TARGET_GAIN, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS)["options"] == [])
check("suggest_multiday_plan_options(target_gain=0, ...) -> no options", suggest_multiday_plan_options(BANKROLL, 0, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS)["options"] == [])
check("suggest_multiday_plan_options(days_available=0, ...) -> no options", suggest_multiday_plan_options(BANKROLL, TARGET_GAIN, AVG_PAYOUT, "pure", None, STOP_LOSS, 0)["options"] == [])

# -- stop_loss=None means vacuously safe here too --
multiday_no_sl = suggest_multiday_plan_options(BANKROLL, TARGET_GAIN, AVG_PAYOUT, "pure", None, None, DAYS, max_total_trades=20)["options"]
check("multiday stop_loss=None -> every option reports survivesFirstLoss=True", all(o["survivesFirstLoss"] for o in multiday_no_sl))

# -- max_total_trades (e.g. max_trades_per_day x days_available, computed by
# the caller) gets clamped to MAX_MULTIDAY_SEARCH_TRADES, with
# cappedAtSearchLimit reporting that it happened, instead of silently
# taking however long an uncapped search would --
big_request = MAX_MULTIDAY_SEARCH_TRADES + 500
capped_result = suggest_multiday_plan_options(BANKROLL, TARGET_GAIN, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS, max_total_trades=big_request)
check("a request over the ceiling reports cappedAtSearchLimit=True", capped_result["cappedAtSearchLimit"] is True)
check(
    f"a request over the ceiling never searches past n={MAX_MULTIDAY_SEARCH_TRADES}",
    all(o["n"] <= MAX_MULTIDAY_SEARCH_TRADES for o in capped_result["options"]),
)
under_cap_result = suggest_multiday_plan_options(BANKROLL, TARGET_GAIN, AVG_PAYOUT, "pure", None, STOP_LOSS, DAYS, max_total_trades=MAX_MULTIDAY_SEARCH_TRADES)
check("a request exactly at the ceiling reports cappedAtSearchLimit=False", under_cap_result["cappedAtSearchLimit"] is False)

print(f"{_passed} / {_passed + _failed} passed")
if _failed:
    raise SystemExit(1)
