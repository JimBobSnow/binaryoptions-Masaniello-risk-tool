# Masaniello Risk Manager — Project Summary

## What this is

A single-page, 100% client-side web app for sizing binary-options trades using the **Masaniello staking method** (a dynamic, target-based position-sizing system built on Pascal's-triangle-style recursion). No backend, no accounts, no analytics, no network calls of any kind. Everything — the active session, full trade history, and all settings — lives in the browser's `localStorage`. Opening `index.html` directly from disk (or from any static host) is the entire deployment story.

Vanilla HTML/CSS/JS, no build step, no framework, no dependencies.

## Files

| File | Role |
|---|---|
| `index.html` | The single page: header, setup form, active-session dashboard, session-history panel, disclaimer modal. All markup lives here; no templating. |
| `masaniello.js` | The staking **engine** — pure math functions only, zero DOM/storage dependencies. Loaded as a plain `<script>` (`window.Masaniello`), also `module.exports`-compatible. |
| `app.js` | All UI logic: state, `localStorage` persistence, event wiring, rendering. One big IIFE. |
| `style.css` | All styling, including the multi-theme system (see below). |
| `tests.html` | A standalone, browser-run automated test suite for `masaniello.js`. Open it directly — it renders PASS/FAIL for every assertion and a final `N / N passed` summary. Currently **36/36 passing**. No test framework; it's a hand-rolled `check(name, actual, expected, epsilon)` harness. |

## The core algorithm (`masaniello.js`)

This is the part that actually matters for correctness — get this wrong and the tool tells someone to risk the wrong amount of real money.

- **`buildTable(N, qAvg)`** — builds `t[n][k]`: the capital growth multiplier such that reaching `k` wins within the next `n` trades, *in any order*, lands on the same final capital. `qAvg` is a decimal (0.80, not 80). This is the classic Masaniello recursion. Diagonal cells `t[m][m] = (1+q)^m` represent "must win every remaining trade."
- **`stakeFraction(n, k, qNext, table, diagonalMode, maxStakePercent)`** — the fraction of *current* capital to stake on the next trade. `qNext` is the actual payout being offered on *this specific trade* (can differ from `qAvg`, which only affects the pre-built table). Two behaviors at the diagonal (`n === k`, i.e. "must win everything left"):
  - `diagonalMode: 'pure'` → stake 100% (the textbook version).
  - `diagonalMode: 'capped'` → stake capped at `maxStakePercent` of current capital instead of going all-in.
- **`nextStake(currentCapital, tradesRemaining, winsStillNeeded, qNext, table, diagonalMode, maxStakePercent)`** — convenience wrapper returning a dollar amount instead of a fraction.
- **`thresholdAmount(bankroll, tpSl)`** — resolves a take-profit/stop-loss config object into a dollar amount. `tpSl = { type: 'percent'|'dollar', value, dollarMode }`. For `type: 'dollar'`, `dollarMode` disambiguates two very different meanings:
  - `'amount'` (default) — "I'm willing to lose/gain $X total from my starting balance."
  - `'floor'` (stop-loss only) — "end the session once my *balance* drops to $X" (not once I've lost $X).
  - `'ceiling'` (take-profit only) — "end once my *balance* reaches $X" (not once I've merely gained $X).
  - This distinction exists because a user reported a $1 stop-loss ending sessions almost instantly — they meant "floor," the app was doing "amount."
- **`winsNeededForRate(n, winRatePct)`** — rounds a target win rate to the nearest whole win count out of `n` trades, clamped to `[1, n]`.
- **`computeMaxTrades(bankroll, winRatePct, avgPayoutPct, diagonalMode, maxStakePercent, minStake=1, maxSearchN=300)`** — answers "how many trades can this balance actually fund at this win rate, given a broker minimum stake?" It scans `n = 1, 2, 3…`, computing what trade-1's stake would be at each `n` (with `k = winsNeededForRate(n, winRatePct)`), and **stops at the first `n` whose trade-1 stake would fall below `minStake`**, reporting `n - 1`. This is deliberate: because `k` jumps in discrete steps as `n` grows, a *later* `n` can occasionally clear the minimum again even though smaller values in between didn't — but "you can plan for 9 trades, just not 7 or 8" isn't a coherent answer, so the first shortfall is treated as the hard ceiling. Returns `{ n, k, achievedWinRatePct, cappedAtSearchLimit }`.

## Session lifecycle & data model (`app.js`)

Three `localStorage` keys, each holding one JSON blob:
- `masaniello_active_session_v1` — the in-progress (or just-ended-but-not-yet-dismissed) session, or absent if none.
- `masaniello_history_v1` — array of archived session records, newest first.
- `masaniello_counter_v1` — `{ count, autoCount }`, a user-adjustable session counter independent of the history array (supports manual +/− nudges, e.g. for sessions tracked on paper).
- `masaniello_theme_v1` — which of the three visual themes is active (see below).

**Session object shape** (`state.activeSession`):
```
{
  id, startedAt, status: 'active'|'ended',
  inputs: {
    bankroll, N, K, avgPayoutPct,
    takeProfit: { type, value, dollarMode, forceEnd },
    stopLoss:  { type, value, dollarMode, forceEnd },
    diagonalMode, maxStakePercent
  },
  currentCapital, tradesRemaining, winsNeeded,
  trades: [{ index, payoutPctUsed, stakeSuggested, stakeUsed, result, capitalAfter }, ...],
  endReason: null | 'take_profit'|'stop_loss'|'target_hit'|'target_unreachable'|'trades_exhausted'|'manual',
  endedAt
}
```

**Setup flow (this evolved significantly from a naive "type in N and K" form):**
1. User enters **starting balance**, a **target win rate %**, and a **default/average payout %**.
2. The app computes every trade-count option from 1 up to a cap of 20 that `computeMaxTrades` confirms is affordable (trade-1 stake ≥ $1), and populates a `<select>` dropdown with entries like `"5 trades (3 wins needed) — $65.75 (+65.75%)"` — the dollar/percent figures are the **projected balance growth if the session lands exactly on target**, computed the same way as the in-session projection box (`bankroll * table[n][k]`).
3. Selecting an option updates three readouts below the dropdown: wins needed, effective win rate (may differ slightly from the target due to rounding), and projected growth ($ and %).
4. User sets take-profit and stop-loss (each: percent-of-balance or dollar; if dollar, further choose amount/floor/ceiling as above), **and** independently toggles whether each one **force-ends the session** when hit or is **"alert only"** (crosses the threshold, shows a warning note, session keeps running — added because the user wanted the option to just get notified rather than have it forced closed).
5. **"Number of trades planned" and "Wins targeted" are never typed in directly** — they're always derived from balance + win rate (this replaced an earlier version where they were plain number inputs).

**End conditions**, checked after every recorded trade, in this priority order:
1. `target_unreachable` — `tradesRemaining < winsNeeded` (losses so far have made the K-win target mathematically impossible). Checked first and labeled distinctly from stop-loss even if capital also happens to have hit $0.
2. `target_hit` — `winsNeeded === 0`.
3. `take_profit` — only if `takeProfit.forceEnd !== false`.
4. `stop_loss` — only if `stopLoss.forceEnd !== false`.
5. `trades_exhausted` — ran out of planned trades without any of the above.

Ending a session (auto or via the "End Session Manually" button) immediately archives a deep-copied record into history and increments the counter (if `autoCount` is on) — independent of the "Start New Session" button, which only clears the *active* slot and never touches history.

**Inline correction:** each trade row's Win/Loss result is a toggle, editable only while the session is still `'active'` (never after archiving, so a completed history record never needs to be un-archived). Editing recomputes every downstream `capitalAfter`, then re-runs the end-condition check (so fixing a misclick can retroactively end the session).

**Payout-per-trade is the crux of correctness for binary options:** the "Payout % for this trade" field is a live, editable input (prefilled from the last trade's actual payout, or the average if none yet), separate from `avgPayoutPct`. The stake *and* the recorded Return for a winning trade are computed from whatever this field says at click-time, never from the average — because real binary-options payouts vary trade to trade, and using the average would make the tool's tracked balance drift from the real broker balance.

## Visual design: three switchable themes

The header has a theme switcher with three buttons. All three are full re-skins of the *same* HTML/JS — one shared functional layer, three CSS token sets — so a bug fix or feature only has to happen once. Preference persists via `masaniello_theme_v1` and is applied before first paint (a small inline `<script>` in `<head>` reads `localStorage` and sets `data-theme` on `<html>` synchronously, avoiding a flash of the wrong theme).

- **Theme 1 ("Ledger")** — light paper background with a subtle ruled-line texture, serif display font (`Iowan Old Style`/Palatino/Georgia) paired with a sans body font, monospace tabular figures for all numbers, dark ink-teal accent, brick-red for losses. Session-active indicator styled as a rotated ink stamp.
- **Theme 2 ("Terminal")** — near-black background, full monospace, amber "phosphor" accent color, subtle CRT scanline texture, a blinking cursor character after the live suggested-stake figure, uppercase section headers, `> ` prefix on field labels.
- **Theme 3 ("Instrument Panel")** — brushed-graphite background, condensed/narrow display font, circular SVG **ring gauges** (not bars) for take-profit/stop-loss distance, a round "dial" for the suggested-stake readout, small corner rivet dots on each card. This is the one theme where take-profit/stop-loss use genuinely different markup (rings) rather than just different colors on the same bar — both the bar and the ring elements exist in the DOM for every theme, and CSS shows/hides the right one per theme.

All three themes are driven by CSS custom properties (`--bg`, `--text`, `--accent`, `--win`, `--loss`, `--on-accent`, `--font-display`, `--font-body`, `--font-mono`, `--radius`, etc.) defined per-theme under `:root[data-theme="ledger"|"terminal"|"gauge"]`, plus a handful of theme-specific decorative rules (the ruled-paper background, the scanlines, the rivets/rings). Almost every component rule references a token rather than a hardcoded color, which is what made adding new themes cheap.

## Testing approach

`tests.html` is the source of truth for algorithm correctness. It loads `masaniello.js` directly and runs hand-derived assertions, including:
- The build prompt's own worked example (N=3, K=1, 100% payout, $100 bankroll) reproduced exactly: stakes of $14.29 → $28.57 → $57.14, and a $114.28/$114.29 final capital regardless of which trade the single win lands on.
- A case where `q_next` (92%) differs from `q_avg` (80%) on trade 1, confirming the stake and the eventual Return both use `q_next`.
- Diagonal-case pure vs. capped mode.
- `thresholdAmount`'s percent/dollar/amount/floor/ceiling matrix, including the exact $1-stop-loss-on-$55-remaining bug scenario, confirmed fixed.
- `computeMaxTrades`, including a fully hand-derived case (bankroll $100, 20% win rate, 100% payout → max 6 trades, since trade 1 at N=7 would need $0.79 < $1) and the degenerate 100%-win-rate case (trade 1 is always the diagonal/full-balance case for any N, so the search legitimately hits its cap rather than finding a real ceiling).

Whenever you (the new AI, or the user) change anything in `masaniello.js`, re-open `tests.html` in a browser and confirm it still says `N / N passed` before trusting the change — this file exists specifically so staking-math regressions are never a guess.

## What's deliberately *not* built

The original build spec had a "nice-to-have, not required for v1" section that was never implemented: daily-goal/sessions-required forecasting, a consecutive-loss countdown warning, a stop-loss-proximity alert (distinct from the hard stop-loss), sound/visual session-end notifications, an auto-copy-balance-to-clipboard toggle, a currency selector, and an auto-log-without-confirmation toggle. None of these exist yet; they were explicitly scoped out, not forgotten.

## A note on working style for whoever picks this up

- The user cares a lot about **correctness of the money math** — several rounds of this project were the user catching a real discrepancy between what the tool showed and what a real broker balance would do (the per-trade-payout requirement, the stop-loss amount-vs-floor ambiguity). Treat any staking-math change as something to verify against `tests.html`, not just eyeball.
- The user has iterated the setup form's *shape* multiple times (plain N/K inputs → win-rate-driven derivation → a balance-affordability-driven trade-count picker with projected growth shown per option). If asked to change the setup flow again, read `app.js`'s `updateComputedPlan`/`applySelectedTradeCount` functions and `masaniello.js`'s `computeMaxTrades` together — they're tightly coupled.
- Copy matters to this user: internal variable names like `N`/`K` were deliberately scrubbed from all user-facing text (labels, error messages, history tags) in favor of plain language ("trades planned", "wins targeted"), while remaining as-is in code. Don't reintroduce jargon into UI strings.
